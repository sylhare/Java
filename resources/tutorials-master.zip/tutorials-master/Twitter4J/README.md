### Relevant articles

- [Introduction to Twitter4J](http://www.baeldung.com/twitter4j)
