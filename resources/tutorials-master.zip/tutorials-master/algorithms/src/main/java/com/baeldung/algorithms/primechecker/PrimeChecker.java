package com.baeldung.algorithms.primechecker;

public interface PrimeChecker <T> {
    
    public boolean isPrime( T number );
}
